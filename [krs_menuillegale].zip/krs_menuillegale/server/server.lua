RegisterNetEvent('krs_menuillegale:handcuff')
AddEventHandler('krs_menuillegale:handcuff', function(target)
	TriggerClientEvent('krs_menuillegale:handcuff', target)
end)

RegisterNetEvent('krs_menuillegale:escort')
AddEventHandler('krs_menuillegale:escort', function(target)
		TriggerClientEvent('krs_menuillegale:escort', target, source)
end)

RegisterNetEvent('krs_menuillegale:putInVehicle')
AddEventHandler('krs_menuillegale:putInVehicle', function(target)
	local xPlayer = ESX.GetPlayerFromId(source)
	TriggerClientEvent('krs_menuillegale:putInVehicle', target)
end)

RegisterNetEvent('krs_menuillegale:OutVehicle')
AddEventHandler('krs_menuillegale:OutVehicle', function(target)
	local xPlayer = ESX.GetPlayerFromId(source)
	TriggerClientEvent('krs_menuillegale:OutVehicle', target)
end)


ESX.RegisterServerCallback('esx-radio:getRadio', function(source, cb, id)
	local statePlayer = Player(id).state.radioChannel
	cb(statePlayer)
end)