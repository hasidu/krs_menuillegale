ESX = exports.es_extended:getSharedObject()


local HaveBagOnHead = false


function Sacco() 

local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
  local player = GetPlayerPed(-1)

  if closestPlayer == -1 or closestDistance > 2.0 then 
      ESX.ShowNotification('Non c\'è nessun giocatore nelle vicinanze')
  else
    if not HaveBagOnHead then
      TriggerServerEvent('krs_sacco:sendclosest', GetPlayerServerId(closestPlayer))
      ESX.ShowNotification('Sacco messo ' .. GetPlayerName(closestPlayer))
      TriggerServerEvent('krs_sacco:closest')
    else
      ESX.ShowNotification('Questo giocatore ha già un sacco in testa')
    end
  end

end


RegisterNetEvent('krs_sacco:mettiSacco', function() -- Funzione per aprire il menu Sacco
  lib.showContext('_sacco') 
end)


RegisterNetEvent('krs_sacco:propSacco', function(giocatore)

    local playerPed = GetPlayerPed(-1)
    PropSacco = CreateObject(GetHashKey("prop_money_bag_01"), 0, 0, 0, true, true, true) 
    AttachEntityToEntity(PropSacco, GetPlayerPed(-1), GetPedBoneIndex(GetPlayerPed(-1), 12844), 0.2, 0.04, 0, 0, 270.0, 60.0, true, true, false, true, 1, true) 
    SetNuiFocus(false,false)
    SendNUIMessage({type = 'openGeneral'})
    HaveBagOnHead = true

end)    

    AddEventHandler('playerSpawned', function() 
    DeleteEntity(PropSacco)
    SetEntityAsNoLongerNeeded(PropSacco)
    SendNUIMessage({type = 'closeAll'})
    HaveBagOnHead = false
end)


RegisterNetEvent('krs_sacco:rimuoviSacco', function(giocatore)

    ESX.ShowNotification('Qualcuno ti ha tolto il sacchetto dalla testa!')
    DeleteEntity(PropSacco)
    SetEntityAsNoLongerNeeded(PropSacco)
    SendNUIMessage({type = 'closeAll'})
    HaveBagOnHead = false

end)



lib.registerContext({
  id = '_sacco',
  title = 'Menu Sacco',
  onExit = function()
  end,
  options = {
      {
          title = 'Usa Sacco',
          icon = 'fa-solid fa-sack-xmark',
          arrow = false,
          onSelect = function(data)
          local player, distance = ESX.Game.GetClosestPlayer()

              if distance ~= -1 and distance <= 2.0 then
                    Sacco()
          else
              ESX.ShowNotification('Non c\'è nessun giocatore nelle vicinanze.')
          end
        end,
      },
      {
          title = 'Rimuovi Sacco',
          icon = 'fa-solid fa-sack-xmark',
          arrow = false,
          onSelect = function(data)
            local player, distance = ESX.Game.GetClosestPlayer()

            if distance ~= -1 and distance <= 2.0 then
                  TriggerServerEvent('krs_sacco:zdejmij')
          else
            ESX.ShowNotification('Non c\'è nessun giocatore nelle vicinanze.')
        end
      end,
      },
      
  },
})
