fx_version 'bodacious'
game 'gta5'
lua54 'yes'

description 'Sacco in testa'

shared_scripts {
	
	'@es_extended/imports.lua',
    '@ox_lib/init.lua',
   
}

client_scripts {

	'client.lua'
}

server_scripts {

    'server.lua'
}

ui_page ('index.html') 

files {
    'index.html'
}