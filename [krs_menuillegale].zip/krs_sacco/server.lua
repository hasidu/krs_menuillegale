ESX = exports.es_extended:getSharedObject()


RegisterServerEvent('krs_sacco:closest', function()
    local name = GetPlayerName(najblizszy)

    TriggerClientEvent('krs_sacco:propSacco', najblizszy)
end)


RegisterServerEvent('krs_sacco:sendclosest', function(closestPlayer)
    najblizszy = closestPlayer
end)


RegisterServerEvent('krs_sacco:zdejmij', function()
    TriggerClientEvent('krs_sacco:rimuoviSacco', najblizszy)
end)

ESX.RegisterUsableItem('sacco', function(source)
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    TriggerClientEvent('krs_sacco:mettiSacco', _source)
    TriggerEvent('krs_sacco:debugger', source)
end)